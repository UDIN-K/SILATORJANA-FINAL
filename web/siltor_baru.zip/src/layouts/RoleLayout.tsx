import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { LogOut, Bell, Menu, User, Home, FileText, Settings, Database, Activity, Users, BarChart3, DollarSign, ClipboardList, X } from 'lucide-react';
import { Button, buttonVariants } from '@/components/ui/button';
import { getUserName, getUserRole } from '@/lib/helpers';
import { useState } from 'react';

const ROLE_MENUS: Record<string, { icon: any; label: string; path: string }[]> = {
  admin: [
    { icon: Home, label: 'Beranda', path: '' },
    { icon: Users, label: 'Manajemen User', path: '/users' },
    { icon: Database, label: 'Master IKU', path: '/master' },
    { icon: Activity, label: 'Monitoring', path: '/monitoring' },
  ],
  pengusul: [
    { icon: Home, label: 'Beranda', path: '' },
    { icon: FileText, label: 'Usulan Saya', path: '/usulan' },
    { icon: Activity, label: 'Monitoring', path: '/monitoring' },
  ],
  verifikator: [
    { icon: Home, label: 'Beranda', path: '' },
    { icon: ClipboardList, label: 'Semua Proposal', path: '/proposals' },
    { icon: Activity, label: 'Monitoring', path: '/monitoring' },
  ],
  ppk: [
    { icon: Home, label: 'Beranda', path: '' },
    { icon: ClipboardList, label: 'Semua Proposal', path: '/proposals' },
    { icon: Activity, label: 'Monitoring', path: '/monitoring' },
  ],
  wadir2: [
    { icon: Home, label: 'Beranda', path: '' },
    { icon: ClipboardList, label: 'Semua Proposal', path: '/proposals' },
    { icon: Activity, label: 'Monitoring', path: '/monitoring' },
  ],
  bendahara: [
    { icon: Home, label: 'Beranda', path: '' },
    { icon: DollarSign, label: 'Pencairan & LPJ', path: '/proposals' },
    { icon: Activity, label: 'Monitoring', path: '/monitoring' },
  ],
  rektorat: [
    { icon: Home, label: 'Beranda', path: '' },
    { icon: BarChart3, label: 'Laporan', path: '/laporan' },
    { icon: Activity, label: 'Monitoring', path: '/monitoring' },
  ],
};

export function RoleLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const role = location.pathname.split('/')[2] || 'user';
  const userName = getUserName();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    navigate('/login');
  };

  const menuItems = ROLE_MENUS[role] || ROLE_MENUS.pengusul;
  const basePath = `/dashboard/${role}`;

  const SidebarContent = () => (
    <>
      <div className="h-16 flex items-center px-6 border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-2 text-primary font-bold text-xl tracking-tight">
          <div className="size-8 rounded-md bg-primary flex items-center justify-center text-primary-foreground font-black text-sm">Si</div>
          LATORJANA
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {menuItems.map((item, index) => {
          const fullPath = basePath + item.path;
          const isActive = item.path === '' ? location.pathname === basePath : location.pathname.startsWith(fullPath);
          return (
            <button key={index}
              onClick={() => { navigate(fullPath); setMobileOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                isActive ? 'bg-blue-50 text-blue-700 hover:bg-blue-100' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}>
              <item.icon className={`size-4.5 ${isActive ? 'text-blue-700' : 'text-slate-400'}`} />
              {item.label}
            </button>
          );
        })}
      </div>

      <div className="p-4 border-t border-slate-100 shrink-0">
        <div className="flex items-center gap-3 px-3 py-2 rounded-md bg-slate-50 border border-slate-100">
          <div className="size-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center"><User className="size-4" /></div>
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium text-slate-900 truncate">{userName}</p>
            <p className="text-xs text-slate-500 capitalize">{role}</p>
          </div>
        </div>
      </div>
    </>
  );

  return (
    <div className="flex min-h-screen w-full bg-slate-50/50">
      {/* Desktop Sidebar */}
      <aside className="w-64 border-r border-slate-200 bg-white shadow-sm flex-col hidden md:flex">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-64 bg-white shadow-xl flex flex-col">
            <div className="absolute top-3 right-3"><Button variant="ghost" size="icon" onClick={() => setMobileOpen(false)}><X className="size-5" /></Button></div>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        {/* Top Navbar */}
        <header className="h-16 border-b border-slate-200 bg-white flex items-center justify-between px-4 sm:px-6 shadow-sm z-10 sticky top-0">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(true)}>
              <Menu className="size-5" />
            </Button>
            <h1 className="text-lg font-semibold text-slate-800 capitalize hidden sm:block">
              Panel {role}
            </h1>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="relative text-slate-500">
              <Bell className="size-5" />
              <span className="absolute top-2 right-2 size-2 bg-red-500 rounded-full border border-white"></span>
            </Button>
            
            <div className="relative">
              <Button
                variant="ghost"
                className="relative size-8 rounded-full !w-8 !h-8 p-0"
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
              >
                <User className="size-5 text-slate-600" />
              </Button>

              {profileDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setProfileDropdownOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-2 w-56 rounded-md border border-slate-200 bg-white shadow-lg z-50 flex flex-col py-1 animate-in fade-in slide-in-from-top-2">
                    <div className="px-3 py-2 text-sm font-semibold text-slate-900 border-b border-slate-100">
                      Akun Saya
                    </div>
                    <div className="p-1">
                      <button 
                        className="w-full text-left px-2 py-1.5 text-sm text-slate-700 hover:bg-slate-100 rounded-sm"
                        onClick={() => {
                          setProfileDropdownOpen(false);
                          navigate(`/dashboard/${role}/profile`);
                        }}
                      >
                        Profil
                      </button>
                      <button 
                        className="w-full text-left px-2 py-1.5 text-sm text-slate-700 hover:bg-slate-100 rounded-sm"
                      >
                        Pengaturan
                      </button>
                    </div>
                    <div className="border-t border-slate-100 p-1">
                      <button 
                        className="w-full flex items-center px-2 py-1.5 text-sm text-red-600 hover:bg-red-50 rounded-sm"
                        onClick={() => {
                          setProfileDropdownOpen(false);
                          handleLogout();
                        }}
                      >
                        <LogOut className="size-4 mr-2" />
                        Keluar
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
