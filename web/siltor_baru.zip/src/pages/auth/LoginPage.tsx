import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Lock, User } from 'lucide-react';
import { account, databases, APPWRITE_DB_ID } from '@/lib/appwrite';
import { Query } from 'appwrite';

export function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    setError('');
    setIsLoading(true);

    try {
      // Query users collection directly via Appwrite SDK
      const data = await databases.listDocuments(APPWRITE_DB_ID, 'users', [
        Query.equal('email', email)
      ]);

      if (!data.documents || data.documents.length === 0) {
        throw new Error('Email tidak ditemukan di sistem.');
      }

      const userDoc = data.documents[0];

      if (userDoc.password !== password) {
        throw new Error('Password salah.');
      }

      // Store user in localStorage
      localStorage.setItem('currentUser', JSON.stringify(userDoc));

      // Navigate based on role
      const userRole = userDoc.role;
      if (userRole === 'admin') navigate('/dashboard/admin');
      else if (userRole === 'verifikator') navigate('/dashboard/verifikator');
      else if (userRole === 'ppk') navigate('/dashboard/ppk');
      else if (userRole === 'bendahara') navigate('/dashboard/bendahara');
      else if (userRole === 'wadir2') navigate('/dashboard/wadir2');
      else if (userRole === 'rektorat') navigate('/dashboard/rektorat');
      else navigate('/dashboard/pengusul');
    } catch (err: any) {
      setError(err.message || 'Login gagal. Periksa email dan password Anda.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-slate-50">
      {/* Visual Side */}
      <div className="hidden lg:flex flex-col justify-center items-center bg-blue-600 text-white p-12 relative overflow-hidden">
        {/* Abstract background elements */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 rounded-full bg-white blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-white blur-3xl"></div>
        </div>
        
        <div className="z-10 text-center max-w-lg">
          <div className="mb-8 inline-flex items-center justify-center p-4 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/20">
            <div className="text-4xl font-black tracking-tight">Si-LATORJANA</div>
          </div>
          <h2 className="text-3xl font-bold mb-4">Sistem Layanan Terpadu</h2>
          <p className="text-blue-100 text-lg">
            Platform manajemen dan monitoring usulan pengadaan barang dan jasa yang terintegrasi.
          </p>
        </div>
      </div>

      {/* Form Side */}
      <div className="flex flex-col justify-center items-center p-6 md:p-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden text-center mb-8">
            <div className="inline-block p-3 bg-blue-600 text-white rounded-xl mb-3">
              <div className="text-2xl font-black">Si-LATORJANA</div>
            </div>
          </div>

          <Card className="border-slate-200 shadow-xl shadow-slate-200/50">
            <CardHeader className="space-y-1 pb-6">
              <CardTitle className="text-2xl font-bold text-center">Masuk ke Sistem</CardTitle>
              <CardDescription className="text-center text-slate-500">
                Silahkan login untuk mengakses panel manajemen Anda
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                {error && (
                  <div className="p-3 bg-red-50 text-red-600 text-sm rounded-md border border-red-200">
                    {error}
                  </div>
                )}
                
                <div className="space-y-4 pt-2">
                  <div className="space-y-2">
                    <Label>Login Cepat (Bypass untuk Testing)</Label>
                    <select 
                      className="w-full mt-1 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val) {
                          setEmail(val);
                          setPassword('123');
                        }
                      }}
                    >
                      <option value="">Pilih Role...</option>
                      <option value="admin@si-latorjana.com">Admin</option>
                      <option value="rektorat@si-latorjana.com">Rektorat Utama</option>
                      <option value="verifikator@si-latorjana.com">Verifikator Utama</option>
                      <option value="ppk@si-latorjana.com">PPK Keuangan</option>
                      <option value="wadir2@si-latorjana.com">Wadir II</option>
                      <option value="bendahara@si-latorjana.com">Bendahara Utama</option>
                      <option value="tik@si-latorjana.com">Pengusul - TIK</option>
                      <option value="mesin@si-latorjana.com">Pengusul - MESIN</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                      <Input id="email" type="email" placeholder="name@example.com" className="pl-9" value={email} onChange={e => setEmail(e.target.value)} required />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Password</Label>
                      <a href="/forgot-password" className="text-xs text-blue-600 hover:underline">Lupa Password?</a>
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                      <Input id="password" type="password" placeholder="••••••••" className="pl-9" value={password} onChange={e => setPassword(e.target.value)} required />
                    </div>
                  </div>
                </div>

                <Button type="submit" disabled={isLoading} className="w-full mt-4 h-11 bg-blue-600 hover:bg-blue-700">
                  {isLoading ? 'Memproses...' : 'Masuk Sekarang'}
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex justify-center border-t border-slate-100 mt-4 pt-6">
              <p className="text-sm text-slate-500">
                &copy; 2026 Si-LATORJANA
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
